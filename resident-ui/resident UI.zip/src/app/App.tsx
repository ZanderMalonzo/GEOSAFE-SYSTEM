import { useState, useEffect, useRef } from "react";
import {
  Home,
  FileText,
  Map,
  Bell,
  User,
  Shield,
  MapPin,
  AlertTriangle,
  Phone,
  Users,
  CheckCircle,
  ChevronRight,
  Droplets,
  Flame,
  Zap,
  Wind,
  Camera,
  RefreshCw,
  Send,
  X,
  Menu,
  LogOut,
  Settings,
  HelpCircle,
  Moon,
  Globe,
  Heart,
  Navigation,
  Plus,
  Clock,
  Filter,
  Eye,
  ArrowLeft,
  Loader,
  CloudRain,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type Screen = "splash" | "login" | "home" | "report" | "map" | "alerts" | "profile" | "rescue" | "family";

const BLUE = "#1565C0";
const RED = "#D32F2F";
const GREEN = "#2E7D32";
const ORANGE = "#F57C00";

// ─── Splash ──────────────────────────────────────────────────────────────────
function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2600);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="flex flex-col items-center justify-center h-full bg-white">
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center gap-5"
      >
        <div className="relative">
          <svg width="88" height="88" viewBox="0 0 88 88" fill="none">
            <path
              d="M44 6C24.12 6 8 22.12 8 42C8 62.32 30.4 74.68 44 82C57.6 74.68 80 62.32 80 42C80 22.12 63.88 6 44 6Z"
              fill={BLUE}
            />
            <circle cx="44" cy="40" r="8" fill="white" />
            <path d="M44 48 C44 48 54 56 54 64 C54 69.52 49.52 74 44 74 C38.48 74 34 69.52 34 64 C34 56 44 48 44 48Z" fill="white" />
          </svg>
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-bold" style={{ color: BLUE }}>GeoSafe</h1>
          <p className="text-sm mt-1" style={{ color: "#616161" }}>Emergency Response Made Faster</p>
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-16 flex flex-col items-center gap-3"
      >
        <div className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: BLUE }}
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 1.2, delay: i * 0.2 }}
            />
          ))}
        </div>
        <p className="text-xs" style={{ color: "#9E9E9E" }}>Barangay Bayanan Emergency System</p>
      </motion.div>
    </div>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState("juan.delacruz@bayanan.gov.ph");
  const [password, setPassword] = useState("••••••••");
  const [remember, setRemember] = useState(false);

  return (
    <div className="flex flex-col h-full bg-white overflow-y-auto">
      {/* Illustration header */}
      <div className="relative flex items-center justify-center pt-12 pb-8" style={{ backgroundColor: "#E3F0FF" }}>
        <svg width="220" height="130" viewBox="0 0 220 130" fill="none">
          <ellipse cx="110" cy="115" rx="90" ry="12" fill="#C5D8F5" />
          {/* Buildings */}
          <rect x="20" y="55" width="35" height="60" rx="3" fill={BLUE} opacity="0.8" />
          <rect x="60" y="35" width="45" height="80" rx="3" fill={BLUE} />
          <rect x="110" y="50" width="38" height="65" rx="3" fill={BLUE} opacity="0.7" />
          <rect x="155" y="62" width="30" height="53" rx="3" fill={BLUE} opacity="0.6" />
          {/* Windows */}
          {[0,1,2].map(r => [0,1].map(c => (
            <rect key={`${r}${c}`} x={24 + c * 14} y={60 + r * 16} width="10" height="10" rx="1" fill="white" opacity="0.6" />
          )))}
          {/* Shield */}
          <path d="M100 15 C100 15 120 20 120 38 C120 52 110 60 100 65 C90 60 80 52 80 38 C80 20 100 15 100 15Z" fill="white" stroke={BLUE} strokeWidth="2" />
          <circle cx="100" cy="38" r="5" fill={BLUE} />
          <path d="M100 43 L100 52" stroke={BLUE} strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div className="absolute bottom-3 left-0 right-0 flex justify-center">
          <div className="flex items-center gap-2 px-4 py-1 rounded-full" style={{ backgroundColor: BLUE }}>
            <Shield size={12} color="white" />
            <span className="text-xs text-white font-medium">Barangay Bayanan</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col px-6 pt-8 gap-5 pb-8">
        <div>
          <h2 className="text-2xl font-bold" style={{ color: "#212121" }}>Welcome Back</h2>
          <p className="text-sm mt-1" style={{ color: "#616161" }}>Sign in to your GeoSafe account</p>
        </div>

        <div className="flex flex-col gap-4">
          <div>
            <label className="text-sm font-medium mb-1 block" style={{ color: "#212121" }}>Email Address</label>
            <input
              className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
              style={{ borderColor: "#E0E0E0", backgroundColor: "#F7F9FC", color: "#212121" }}
              value={email}
              onChange={e => setEmail(e.target.value)}
              onFocus={e => (e.target.style.borderColor = BLUE)}
              onBlur={e => (e.target.style.borderColor = "#E0E0E0")}
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block" style={{ color: "#212121" }}>Password</label>
            <input
              type="password"
              className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
              style={{ borderColor: "#E0E0E0", backgroundColor: "#F7F9FC", color: "#212121" }}
              value={password}
              onChange={e => setPassword(e.target.value)}
              onFocus={e => (e.target.style.borderColor = BLUE)}
              onBlur={e => (e.target.style.borderColor = "#E0E0E0")}
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <div
                className="w-5 h-5 rounded flex items-center justify-center border-2 transition-all cursor-pointer"
                style={{ borderColor: remember ? BLUE : "#BDBDBD", backgroundColor: remember ? BLUE : "white" }}
                onClick={() => setRemember(!remember)}
              >
                {remember && <CheckCircle size={12} color="white" />}
              </div>
              <span className="text-sm" style={{ color: "#616161" }}>Remember me</span>
            </label>
            <button className="text-sm font-medium" style={{ color: BLUE }}>Forgot Password?</button>
          </div>
        </div>

        <button
          onClick={onLogin}
          className="w-full py-4 rounded-2xl font-semibold text-white text-base transition-transform active:scale-[0.98]"
          style={{ backgroundColor: BLUE }}
        >
          LOGIN
        </button>

        <div className="text-center">
          <span className="text-sm" style={{ color: "#616161" }}>Don't have an account? </span>
          <button className="text-sm font-semibold" style={{ color: BLUE }}>Create Account</button>
        </div>
      </div>
    </div>
  );
}

// ─── Home Screen ─────────────────────────────────────────────────────────────
function HomeScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [sosPressed, setSosPressed] = useState(false);
  const [sosSent, setSosSent] = useState(false);

  const handleSOS = () => {
    setSosPressed(true);
    setTimeout(() => { setSosSent(true); setSosPressed(false); }, 800);
    setTimeout(() => setSosSent(false), 3500);
  };

  const alerts = [
    { type: "Flood", color: BLUE, time: "2 min ago", dist: "0.3 km", icon: Droplets },
    { type: "Fire", color: RED, time: "15 min ago", dist: "1.2 km", icon: Flame },
    { type: "Road Block", color: ORANGE, time: "1 hr ago", dist: "0.8 km", icon: AlertTriangle },
  ];

  const recentReports = [
    { type: "Flooding", status: "Responding", statusColor: ORANGE, date: "Jul 23, 10:14 AM" },
    { type: "Fire Incident", status: "Resolved", statusColor: GREEN, date: "Jul 22, 6:30 PM" },
    { type: "Medical Emergency", status: "Completed", statusColor: "#616161", date: "Jul 21, 3:00 PM" },
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto" style={{ backgroundColor: "#F7F9FC" }}>
      {/* Top App Bar */}
      <div className="flex items-center justify-between px-5 pt-6 pb-4 bg-white shadow-sm">
        <div className="flex items-center gap-2">
          <Shield size={22} color={BLUE} />
          <span className="text-lg font-bold" style={{ color: BLUE }}>GeoSafe</span>
        </div>
        <div className="flex items-center gap-3">
          <button className="relative p-2 rounded-full" style={{ backgroundColor: "#F7F9FC" }}>
            <Bell size={20} color="#212121" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ backgroundColor: RED }} />
          </button>
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: BLUE }}>
            JD
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-5 px-4 pb-4 pt-5">
        {/* Greeting */}
        <div>
          <p className="text-sm" style={{ color: "#616161" }}>Good morning,</p>
          <h2 className="text-xl font-bold" style={{ color: "#212121" }}>Juan Dela Cruz</h2>
        </div>

        {/* Weather Card */}
        <div className="rounded-2xl p-4 shadow-sm" style={{ backgroundColor: BLUE }}>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-blue-100 font-medium mb-1">Today's Weather</p>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-bold text-white">28°C</span>
                <span className="text-blue-200 text-sm mb-1">Partly Cloudy</span>
              </div>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-1">
                  <Droplets size={12} color="#90CAF9" />
                  <span className="text-xs" style={{ color: "#BBDEFB" }}>Rain: 60%</span>
                </div>
                <div className="flex items-center gap-1">
                  <Wind size={12} color="#90CAF9" />
                  <span className="text-xs" style={{ color: "#BBDEFB" }}>18 km/h</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <CloudRain size={40} color="white" opacity={0.6} />
              <p className="text-xs text-blue-100 mt-1">Wed, Jul 23</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-blue-400">
            <div className="flex items-center gap-2">
              <AlertTriangle size={13} color="#FFD54F" />
              <span className="text-xs font-medium" style={{ color: "#FFD54F" }}>Rain warning in effect — Barangay Bayanan</span>
            </div>
          </div>
        </div>

        {/* SOS Emergency Card */}
        <motion.div
          className="rounded-2xl p-5 shadow-md overflow-hidden relative"
          style={{ backgroundColor: RED }}
          animate={sosPressed ? { scale: 0.97 } : { scale: 1 }}
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-red-100 tracking-widest">EMERGENCY</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Emergency Rescue</h3>
              <p className="text-xs" style={{ color: "#FFCDD2" }}>Tap once to send your location immediately.</p>
            </div>
            <motion.button
              className="w-16 h-16 rounded-full bg-white flex items-center justify-center font-black text-lg shadow-lg"
              style={{ color: RED }}
              onClick={handleSOS}
              whileTap={{ scale: 0.92 }}
            >
              SOS
            </motion.button>
          </div>
          {sosSent && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 flex items-center gap-2 bg-white/20 rounded-xl px-3 py-2"
            >
              <CheckCircle size={14} color="white" />
              <span className="text-xs text-white font-medium">Location sent! Responders notified.</span>
            </motion.div>
          )}
        </motion.div>

        {/* Quick Actions */}
        <div>
          <h3 className="text-base font-semibold mb-3" style={{ color: "#212121" }}>Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: FileText, label: "Report Disaster", color: BLUE, bg: "#E3F0FF", screen: "report" as Screen },
              { icon: Phone, label: "Request Rescue", color: RED, bg: "#FFEBEE", screen: "rescue" as Screen },
              { icon: MapPin, label: "Evacuation Centers", color: GREEN, bg: "#E8F5E9", screen: "map" as Screen },
              { icon: Users, label: "Family Safety", color: ORANGE, bg: "#FFF3E0", screen: "family" as Screen },
            ].map(({ icon: Icon, label, color, bg, screen }) => (
              <button
                key={label}
                onClick={() => onNavigate(screen)}
                className="flex flex-col items-start gap-3 p-4 rounded-2xl bg-white shadow-sm transition-transform active:scale-[0.97]"
                style={{ border: "1px solid #F0F0F0" }}
              >
                <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: bg }}>
                  <Icon size={22} color={color} />
                </div>
                <span className="text-sm font-semibold text-left leading-tight" style={{ color: "#212121" }}>{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Nearby Alerts */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold" style={{ color: "#212121" }}>Nearby Alerts</h3>
            <button className="text-xs font-medium" style={{ color: BLUE }}>See All</button>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
            {alerts.map(({ type, color, time, dist, icon: Icon }) => (
              <div
                key={type}
                className="flex-shrink-0 w-44 bg-white rounded-2xl p-4 shadow-sm"
                style={{ border: "1px solid #F0F0F0" }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: color + "20" }}>
                    <Icon size={14} color={color} />
                  </div>
                  <span className="text-sm font-semibold" style={{ color: "#212121" }}>{type}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-xs" style={{ color: "#616161" }}>{time}</span>
                  <span className="text-xs" style={{ color: "#616161" }}>{dist} away</span>
                </div>
                <button className="mt-3 text-xs font-medium" style={{ color: BLUE }}>View Details →</button>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Reports */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold" style={{ color: "#212121" }}>My Recent Reports</h3>
          </div>
          <div className="flex flex-col gap-2">
            {recentReports.map(({ type, status, statusColor, date }) => (
              <div
                key={type}
                className="flex items-center bg-white rounded-2xl px-4 py-3 shadow-sm"
                style={{ border: "1px solid #F0F0F0" }}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: "#F7F9FC" }}>
                  <FileText size={18} color={BLUE} />
                </div>
                <div className="flex-1 ml-3">
                  <p className="text-sm font-semibold" style={{ color: "#212121" }}>{type}</p>
                  <p className="text-xs" style={{ color: "#9E9E9E" }}>{date}</p>
                </div>
                <span
                  className="text-xs font-medium px-2 py-1 rounded-full"
                  style={{ backgroundColor: statusColor + "18", color: statusColor }}
                >
                  {status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Report Screen ────────────────────────────────────────────────────────────
function ReportScreen({ onBack }: { onBack: () => void }) {
  const [incidentType, setIncidentType] = useState("Flood");
  const [desc, setDesc] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const types = ["Flood", "Fire", "Earthquake", "Typhoon", "Landslide", "Medical", "Other"];
  const typeColors: Record<string, string> = {
    Flood: BLUE, Fire: RED, Earthquake: ORANGE, Typhoon: BLUE,
    Landslide: "#6D4C41", Medical: RED, Other: "#616161",
  };

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); setSubmitted(true); }, 1500);
  };

  if (submitted) {
    return (
      <div className="flex flex-col h-full items-center justify-center px-6 bg-white gap-6">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200 }}
          className="w-24 h-24 rounded-full flex items-center justify-center"
          style={{ backgroundColor: GREEN + "20" }}
        >
          <CheckCircle size={52} color={GREEN} />
        </motion.div>
        <div className="text-center">
          <h2 className="text-2xl font-bold" style={{ color: "#212121" }}>Report Submitted!</h2>
          <p className="text-sm mt-2" style={{ color: "#616161" }}>Your report has been received by local responders.</p>
        </div>
        <div className="w-full rounded-2xl p-5" style={{ backgroundColor: "#F7F9FC", border: "1px solid #E0E0E0" }}>
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm" style={{ color: "#616161" }}>Reference Number</span>
            <span className="font-bold text-sm" style={{ color: "#212121" }}>#GS-2024-07423</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm" style={{ color: "#616161" }}>Est. Response Time</span>
            <span className="font-bold text-sm" style={{ color: ORANGE }}>~15 minutes</span>
          </div>
        </div>
        <button
          onClick={onBack}
          className="w-full py-4 rounded-2xl font-semibold text-white text-base"
          style={{ backgroundColor: BLUE }}
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: "#F7F9FC" }}>
      {/* Header */}
      <div className="flex items-center gap-4 px-5 pt-6 pb-4 bg-white shadow-sm">
        <button onClick={onBack} className="p-2 rounded-full" style={{ backgroundColor: "#F7F9FC" }}>
          <ArrowLeft size={20} color="#212121" />
        </button>
        <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Report Disaster</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-5">
        {/* Incident Type */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <label className="text-sm font-semibold block mb-3" style={{ color: "#212121" }}>Incident Type</label>
          <div className="grid grid-cols-3 gap-2">
            {types.map(type => (
              <button
                key={type}
                onClick={() => setIncidentType(type)}
                className="py-2 px-2 rounded-xl text-xs font-medium border-2 transition-all"
                style={{
                  borderColor: incidentType === type ? typeColors[type] : "#E0E0E0",
                  backgroundColor: incidentType === type ? typeColors[type] + "15" : "white",
                  color: incidentType === type ? typeColors[type] : "#616161",
                }}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* GPS Location */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <label className="text-sm font-semibold block mb-3" style={{ color: "#212121" }}>Current Location</label>
          <div className="flex items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: "#F7F9FC", border: "1px solid #E0E0E0" }}>
            <MapPin size={18} color={BLUE} />
            <div className="flex-1">
              <p className="text-sm font-medium" style={{ color: "#212121" }}>Bayanan, Muntinlupa City</p>
              <p className="text-xs" style={{ color: "#9E9E9E" }}>14.3972° N, 121.0200° E</p>
            </div>
            <button className="p-2 rounded-lg" style={{ backgroundColor: "#E3F0FF" }}>
              <RefreshCw size={14} color={BLUE} />
            </button>
          </div>
        </div>

        {/* Photo Upload */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <label className="text-sm font-semibold block mb-3" style={{ color: "#212121" }}>Upload Photo</label>
          <div
            className="flex flex-col items-center justify-center rounded-xl py-8 gap-3 cursor-pointer"
            style={{ backgroundColor: "#F7F9FC", border: "2px dashed #E0E0E0" }}
          >
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: "#E3F0FF" }}>
              <Camera size={22} color={BLUE} />
            </div>
            <p className="text-sm font-medium" style={{ color: BLUE }}>Tap to add a photo</p>
            <p className="text-xs" style={{ color: "#9E9E9E" }}>Supports JPG, PNG up to 10MB</p>
          </div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <label className="text-sm font-semibold block mb-3" style={{ color: "#212121" }}>Description</label>
          <textarea
            className="w-full text-sm rounded-xl p-3 resize-none outline-none"
            style={{ backgroundColor: "#F7F9FC", border: "1px solid #E0E0E0", color: "#212121", minHeight: 100 }}
            placeholder="Describe the incident in detail..."
            value={desc}
            onChange={e => setDesc(e.target.value)}
          />
        </div>

        {/* Severity */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <label className="text-sm font-semibold" style={{ color: "#212121" }}>Severity Estimate</label>
            <span className="text-xs font-medium px-3 py-1 rounded-full" style={{ backgroundColor: ORANGE + "20", color: ORANGE }}>
              Auto-estimated
            </span>
          </div>
          <div className="mt-3 flex gap-2">
            {["Low", "Medium", "High"].map((level, i) => (
              <div
                key={level}
                className="flex-1 h-2 rounded-full"
                style={{ backgroundColor: i <= 1 ? ORANGE : "#E0E0E0" }}
              />
            ))}
          </div>
          <p className="text-xs mt-2" style={{ color: "#616161" }}>Based on incident type and current weather conditions</p>
        </div>
      </div>

      {/* Sticky Submit */}
      <div className="px-4 py-4 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.06)]">
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full py-4 rounded-2xl font-semibold text-white text-base flex items-center justify-center gap-2 transition-opacity"
          style={{ backgroundColor: BLUE, opacity: loading ? 0.8 : 1 }}
        >
          {loading ? <Loader size={18} className="animate-spin" /> : <Send size={18} />}
          {loading ? "Submitting..." : "Submit Report"}
        </button>
      </div>
    </div>
  );
}

// ─── Map Screen ───────────────────────────────────────────────────────────────
function MapScreen() {
  const [showLegend, setShowLegend] = useState(false);

  const markers = [
    { x: 52, y: 38, type: "danger", label: "Flood Zone", color: BLUE },
    { x: 70, y: 55, type: "fire", label: "Fire Incident", color: RED },
    { x: 30, y: 62, type: "safe", label: "Evacuation Center A", color: GREEN },
    { x: 65, y: 25, type: "safe", label: "Evacuation Center B", color: GREEN },
    { x: 45, y: 70, type: "warning", label: "Road Closure", color: ORANGE },
    { x: 20, y: 40, type: "responder", label: "Responder Unit 3", color: "#7B1FA2" },
  ];

  return (
    <div className="flex flex-col h-full relative" style={{ backgroundColor: "#F7F9FC" }}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-6 pb-4 bg-white shadow-sm z-10">
        <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Emergency Map</h2>
        <button className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium" style={{ backgroundColor: "#E3F0FF", color: BLUE }}>
          <Filter size={14} />
          Filter
        </button>
      </div>

      {/* Map Canvas */}
      <div className="relative flex-1 overflow-hidden">
        {/* Simulated map grid */}
        <svg className="absolute inset-0 w-full h-full" style={{ backgroundColor: "#E8EDF5" }}>
          {/* Grid lines */}
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={`v${i}`} x1={`${i * 9}%`} y1="0" x2={`${i * 9}%`} y2="100%" stroke="#D4DCE8" strokeWidth="1" />
          ))}
          {Array.from({ length: 18 }).map((_, i) => (
            <line key={`h${i}`} x1="0" y1={`${i * 7}%`} x2="100%" y2={`${i * 7}%`} stroke="#D4DCE8" strokeWidth="1" />
          ))}
          {/* Roads */}
          <path d="M 0 50% L 100% 45%" stroke="#C5CDD8" strokeWidth="12" />
          <path d="M 45% 0 L 48% 100%" stroke="#C5CDD8" strokeWidth="8" />
          <path d="M 10% 75% L 90% 70%" stroke="#C5CDD8" strokeWidth="6" />
          {/* Road labels */}
          <rect x="30%" y="44%" width="12%" height="5%" rx="3" fill="white" opacity="0.8" />
          <text x="36%" y="47.5%" textAnchor="middle" fill="#616161" fontSize="9">Bayanan Ave</text>
          {/* Water body */}
          <ellipse cx="15%" cy="35%" rx="12%" ry="8%" fill="#B3D4F0" opacity="0.5" />
          {/* Green zones */}
          <rect x="55%" y="60%" width="25%" height="20%" rx="5" fill="#A5D6A7" opacity="0.4" />
          <rect x="5%" y="55%" width="20%" height="15%" rx="5" fill="#A5D6A7" opacity="0.4" />
          {/* User location pulse */}
          <circle cx="50%" cy="52%" r="20" fill={BLUE} opacity="0.12" />
          <circle cx="50%" cy="52%" r="12" fill={BLUE} opacity="0.18" />
          <circle cx="50%" cy="52%" r="6" fill={BLUE} />
          <circle cx="50%" cy="52%" r="3" fill="white" />
          {/* Map markers */}
          {markers.map(({ x, y, color, label }, i) => (
            <g key={i}>
              <circle cx={`${x}%`} cy={`${y}%`} r="10" fill={color} opacity="0.2" />
              <circle cx={`${x}%`} cy={`${y}%`} r="6" fill={color} />
              <circle cx={`${x}%`} cy={`${y}%`} r="2.5" fill="white" />
            </g>
          ))}
        </svg>

        {/* Floating buttons */}
        <div className="absolute right-4 bottom-6 flex flex-col gap-3">
          <button
            className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg"
            style={{ backgroundColor: "white" }}
          >
            <Navigation size={20} color={BLUE} />
          </button>
          <button
            className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg"
            style={{ backgroundColor: RED }}
          >
            <Plus size={20} color="white" />
          </button>
        </div>

        {/* Legend toggle */}
        <button
          onClick={() => setShowLegend(!showLegend)}
          className="absolute left-4 bottom-6 px-4 py-2 rounded-2xl shadow-lg font-medium text-sm flex items-center gap-2"
          style={{ backgroundColor: "white", color: "#212121" }}
        >
          <Eye size={14} />
          Legend
        </button>
      </div>

      {/* Legend Bottom Sheet */}
      <AnimatePresence>
        {showLegend && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl p-6 shadow-[0_-4px_30px_rgba(0,0,0,0.12)] z-20"
          >
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-base font-bold" style={{ color: "#212121" }}>Map Legend</h3>
              <button onClick={() => setShowLegend(false)} className="p-1">
                <X size={20} color="#616161" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { color: RED, label: "High Risk Zone" },
                { color: ORANGE, label: "Medium Risk" },
                { color: GREEN, label: "Safe / Evacuation Area" },
                { color: BLUE, label: "Flood Zone" },
                { color: "#7B1FA2", label: "Responder Unit" },
                { color: "#212121", label: "Road Closure" },
              ].map(({ color, label }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                  <span className="text-sm" style={{ color: "#212121" }}>{label}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Alerts Screen ────────────────────────────────────────────────────────────
function AlertsScreen() {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "Flood", "Fire", "Earthquake", "Weather"];

  const alerts = [
    {
      id: 1, type: "Flood", icon: Droplets, color: BLUE, severity: "High",
      title: "Flood Warning — Bayanan Creek",
      desc: "Water levels rising rapidly. Residents near the creek are advised to evacuate immediately.",
      time: "5 minutes ago", unread: true,
    },
    {
      id: 2, type: "Weather", icon: CloudRain, color: "#1976D2", severity: "Medium",
      title: "Heavy Rain Advisory",
      desc: "Expect heavy rainfall of 15–25mm/hr until 9:00 PM. Avoid low-lying areas.",
      time: "42 minutes ago", unread: true,
    },
    {
      id: 3, type: "Fire", icon: Flame, color: RED, severity: "High",
      title: "Fire Incident — Phase 5",
      desc: "BFP units responding to a structure fire on Block 12, Phase 5. Keep area clear.",
      time: "1 hour ago", unread: false,
    },
    {
      id: 4, type: "Earthquake", icon: Zap, color: ORANGE, severity: "Low",
      title: "Minor Tremor Felt",
      desc: "A magnitude 3.1 tremor was recorded at 6:05 AM. No structural damage reported.",
      time: "3 hours ago", unread: false,
    },
  ];

  const severityColor: Record<string, string> = { High: RED, Medium: ORANGE, Low: GREEN };

  const filtered = filter === "All" ? alerts : alerts.filter(a => a.type === filter);

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: "#F7F9FC" }}>
      {/* Header */}
      <div className="bg-white px-5 pt-6 pb-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Alerts</h2>
          <span className="text-xs font-medium px-2 py-1 rounded-full" style={{ backgroundColor: RED + "18", color: RED }}>
            2 Unread
          </span>
        </div>
        {/* Filter chips */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all"
              style={{
                backgroundColor: filter === f ? BLUE : "#F7F9FC",
                color: filter === f ? "white" : "#616161",
                border: `1px solid ${filter === f ? BLUE : "#E0E0E0"}`,
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pt-4 pb-4 flex flex-col gap-3">
        {filtered.map(alert => (
          <motion.div
            key={alert.id}
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-4 shadow-sm relative overflow-hidden"
            style={{ border: alert.unread ? `2px solid ${alert.color}25` : "1px solid #F0F0F0" }}
          >
            {alert.unread && (
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full" style={{ backgroundColor: RED }} />
            )}
            <div className="flex items-start gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: alert.color + "18" }}
              >
                <alert.icon size={20} color={alert.color} />
              </div>
              <div className="flex-1 pr-4">
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className="text-xs font-medium px-2 py-0.5 rounded-full"
                    style={{ backgroundColor: severityColor[alert.severity] + "18", color: severityColor[alert.severity] }}
                  >
                    {alert.severity}
                  </span>
                </div>
                <h4 className="text-sm font-semibold mb-1" style={{ color: "#212121" }}>{alert.title}</h4>
                <p className="text-xs leading-relaxed" style={{ color: "#616161" }}>{alert.desc}</p>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-1">
                    <Clock size={11} color="#9E9E9E" />
                    <span className="text-xs" style={{ color: "#9E9E9E" }}>{alert.time}</span>
                  </div>
                  <button className="text-xs font-medium" style={{ color: BLUE }}>Read More →</button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ─── Rescue Screen ────────────────────────────────────────────────────────────
function RescueScreen({ onBack }: { onBack: () => void }) {
  const [step, setStep] = useState<"form" | "tracking">("form");
  const [count, setCount] = useState(1);
  const [hasPWD, setHasPWD] = useState(false);
  const [hasMedical, setHasMedical] = useState(false);

  const statusSteps = [
    { label: "Request Submitted", done: true },
    { label: "Accepted by BDRRMC", done: true },
    { label: "Responder Assigned", done: true },
    { label: "On The Way", done: false },
    { label: "Completed", done: false },
  ];

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: "#F7F9FC" }}>
      <div className="flex items-center gap-4 px-5 pt-6 pb-4 bg-white shadow-sm">
        <button onClick={onBack} className="p-2 rounded-full" style={{ backgroundColor: "#F7F9FC" }}>
          <ArrowLeft size={20} color="#212121" />
        </button>
        <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Request Rescue</h2>
      </div>

      {step === "form" ? (
        <>
          <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-4">
            <div className="bg-white rounded-2xl p-5 shadow-sm">
              <label className="text-sm font-semibold block mb-2" style={{ color: "#212121" }}>Current Location</label>
              <div className="flex items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: "#F7F9FC", border: "1px solid #E0E0E0" }}>
                <MapPin size={18} color={RED} />
                <div>
                  <p className="text-sm font-medium" style={{ color: "#212121" }}>Bayanan, Muntinlupa City</p>
                  <p className="text-xs" style={{ color: "#9E9E9E" }}>14.3972° N, 121.0200° E</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 shadow-sm">
              <label className="text-sm font-semibold block mb-3" style={{ color: "#212121" }}>Number of People</label>
              <div className="flex items-center gap-4">
                <button
                  className="w-10 h-10 rounded-full border-2 flex items-center justify-center text-xl font-bold"
                  style={{ borderColor: BLUE, color: BLUE }}
                  onClick={() => setCount(Math.max(1, count - 1))}
                >−</button>
                <span className="text-2xl font-bold w-8 text-center" style={{ color: "#212121" }}>{count}</span>
                <button
                  className="w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold text-white"
                  style={{ backgroundColor: BLUE }}
                  onClick={() => setCount(count + 1)}
                >+</button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 shadow-sm flex flex-col gap-4">
              <label className="text-sm font-semibold" style={{ color: "#212121" }}>Special Needs</label>
              {[
                { label: "PWD Present", val: hasPWD, set: setHasPWD },
                { label: "Medical Emergency", val: hasMedical, set: setHasMedical },
              ].map(({ label, val, set }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-sm" style={{ color: "#212121" }}>{label}</span>
                  <div
                    className="w-12 h-6 rounded-full flex items-center px-1 cursor-pointer transition-all"
                    style={{ backgroundColor: val ? BLUE : "#E0E0E0" }}
                    onClick={() => set(!val)}
                  >
                    <motion.div
                      animate={{ x: val ? 24 : 0 }}
                      className="w-4 h-4 rounded-full bg-white shadow"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl p-5 shadow-sm">
              <label className="text-sm font-semibold block mb-2" style={{ color: "#212121" }}>Additional Details</label>
              <textarea
                className="w-full text-sm rounded-xl p-3 resize-none outline-none"
                style={{ backgroundColor: "#F7F9FC", border: "1px solid #E0E0E0", color: "#212121", minHeight: 80 }}
                placeholder="Describe your situation..."
              />
            </div>
          </div>
          <div className="px-4 py-4 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.06)]">
            <button
              onClick={() => setStep("tracking")}
              className="w-full py-4 rounded-2xl font-semibold text-white text-base"
              style={{ backgroundColor: RED }}
            >
              Submit Rescue Request
            </button>
          </div>
        </>
      ) : (
        <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-5">
          <div className="bg-white rounded-2xl p-5 shadow-sm text-center">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3" style={{ backgroundColor: GREEN + "18" }}>
              <CheckCircle size={36} color={GREEN} />
            </div>
            <h3 className="text-lg font-bold" style={{ color: "#212121" }}>Request Received</h3>
            <p className="text-sm mt-1" style={{ color: "#616161" }}>Ref: #RQ-2024-00921</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm">
            <h4 className="text-sm font-bold mb-4" style={{ color: "#212121" }}>Rescue Status</h4>
            <div className="flex flex-col gap-0">
              {statusSteps.map(({ label, done }, i) => (
                <div key={label} className="flex items-start gap-3">
                  <div className="flex flex-col items-center">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: done ? GREEN : "#E0E0E0" }}
                    >
                      {done ? <CheckCircle size={14} color="white" /> : <div className="w-2.5 h-2.5 rounded-full bg-white" />}
                    </div>
                    {i < statusSteps.length - 1 && (
                      <div className="w-0.5 h-6 my-0.5" style={{ backgroundColor: done ? GREEN : "#E0E0E0" }} />
                    )}
                  </div>
                  <p
                    className="text-sm pt-1"
                    style={{ color: done ? "#212121" : "#9E9E9E", fontWeight: done ? 600 : 400 }}
                  >
                    {label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={onBack}
            className="w-full py-4 rounded-2xl font-semibold text-base"
            style={{ backgroundColor: "#E3F0FF", color: BLUE }}
          >
            Back to Home
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Family Safety Screen ─────────────────────────────────────────────────────
function FamilyScreen({ onBack }: { onBack: () => void }) {
  const members = [
    { name: "Maria Dela Cruz", rel: "Spouse", status: "Safe", initials: "MD" },
    { name: "Carlo Dela Cruz", rel: "Son", status: "Safe", initials: "CD" },
    { name: "Lola Rosa", rel: "Mother", status: "Unknown", initials: "LR" },
    { name: "Kuya Bert", rel: "Brother", status: "Needs Help", initials: "KB" },
  ];

  const statusInfo: Record<string, { color: string; bg: string }> = {
    Safe: { color: GREEN, bg: GREEN + "18" },
    "Needs Help": { color: RED, bg: RED + "18" },
    Unknown: { color: ORANGE, bg: ORANGE + "18" },
  };

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: "#F7F9FC" }}>
      <div className="flex items-center gap-4 px-5 pt-6 pb-4 bg-white shadow-sm">
        <button onClick={onBack} className="p-2 rounded-full" style={{ backgroundColor: "#F7F9FC" }}>
          <ArrowLeft size={20} color="#212121" />
        </button>
        <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Family Safety</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-4">
        {/* Share My Location */}
        <button
          className="w-full py-4 rounded-2xl font-semibold text-white text-sm flex items-center justify-center gap-2"
          style={{ backgroundColor: BLUE }}
        >
          <MapPin size={18} />
          Share My Location
        </button>

        {members.map(({ name, rel, status, initials }) => {
          const si = statusInfo[status];
          return (
            <div key={name} className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: "1px solid #F0F0F0" }}>
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold"
                  style={{ backgroundColor: BLUE }}
                >
                  {initials}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold" style={{ color: "#212121" }}>{name}</p>
                  <p className="text-xs" style={{ color: "#9E9E9E" }}>{rel}</p>
                </div>
                <span
                  className="text-xs font-semibold px-3 py-1 rounded-full"
                  style={{ backgroundColor: si.bg, color: si.color }}
                >
                  {status}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  className="flex-1 py-2 rounded-xl text-xs font-medium border"
                  style={{ borderColor: "#E0E0E0", color: "#212121" }}
                >
                  Update Status
                </button>
                <button
                  className="flex-1 py-2 rounded-xl text-xs font-medium text-white flex items-center justify-center gap-1"
                  style={{ backgroundColor: GREEN }}
                >
                  <Phone size={12} />
                  Call
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Profile Screen ───────────────────────────────────────────────────────────
function ProfileScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifs, setNotifs] = useState(true);

  const menuItems = [
    { icon: Globe, label: "Language", value: "Filipino" },
    { icon: Bell, label: "Notification Settings", toggle: notifs, setToggle: setNotifs },
    { icon: Moon, label: "Dark Mode", toggle: darkMode, setToggle: setDarkMode },
    { icon: User, label: "Privacy Settings" },
    { icon: HelpCircle, label: "Help Center" },
    { icon: LogOut, label: "Logout", danger: true },
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto" style={{ backgroundColor: "#F7F9FC" }}>
      {/* Header */}
      <div className="bg-white px-5 pt-6 pb-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-xl font-bold" style={{ backgroundColor: BLUE }}>
            JD
          </div>
          <div>
            <h2 className="text-lg font-bold" style={{ color: "#212121" }}>Juan Dela Cruz</h2>
            <p className="text-sm" style={{ color: "#616161" }}>Resident — Bayanan, Muntinlupa</p>
            <p className="text-xs mt-0.5" style={{ color: "#9E9E9E" }}>+63 917 123 4567</p>
          </div>
          <button className="ml-auto p-2 rounded-xl" style={{ backgroundColor: "#F7F9FC" }}>
            <Settings size={18} color={BLUE} />
          </button>
        </div>
      </div>

      <div className="px-4 py-5 flex flex-col gap-4">
        {/* Emergency Contacts */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <h4 className="text-sm font-bold mb-3" style={{ color: "#212121" }}>Emergency Contacts</h4>
          {[
            { name: "Maria Dela Cruz", rel: "Spouse", phone: "+63 917 555 0011" },
            { name: "Dr. Ramon Cruz", rel: "Doctor", phone: "+63 2 8888 0000" },
          ].map(c => (
            <div key={c.name} className="flex items-center gap-3 py-3 border-b last:border-0" style={{ borderColor: "#F0F0F0" }}>
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: BLUE + "80" }}>
                {c.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium" style={{ color: "#212121" }}>{c.name}</p>
                <p className="text-xs" style={{ color: "#9E9E9E" }}>{c.rel} · {c.phone}</p>
              </div>
              <button className="p-2 rounded-xl" style={{ backgroundColor: GREEN + "18" }}>
                <Phone size={14} color={GREEN} />
              </button>
            </div>
          ))}
        </div>

        {/* Settings */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {menuItems.map(({ icon: Icon, label, value, toggle, setToggle, danger }, i) => (
            <div
              key={label}
              className="flex items-center gap-3 px-5 py-4 cursor-pointer"
              style={{ borderBottom: i < menuItems.length - 1 ? "1px solid #F5F5F5" : "none" }}
            >
              <Icon size={18} color={danger ? RED : "#616161"} />
              <span className="flex-1 text-sm font-medium" style={{ color: danger ? RED : "#212121" }}>{label}</span>
              {value && <span className="text-sm" style={{ color: "#9E9E9E" }}>{value}</span>}
              {typeof toggle === "boolean" && setToggle ? (
                <div
                  className="w-10 h-5 rounded-full flex items-center px-0.5 cursor-pointer transition-all"
                  style={{ backgroundColor: toggle ? BLUE : "#E0E0E0" }}
                  onClick={() => setToggle(!toggle)}
                >
                  <motion.div
                    animate={{ x: toggle ? 20 : 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="w-4 h-4 rounded-full bg-white shadow"
                  />
                </div>
              ) : !danger ? (
                <ChevronRight size={16} color="#BDBDBD" />
              ) : null}
            </div>
          ))}
        </div>

        <p className="text-center text-xs" style={{ color: "#BDBDBD" }}>GeoSafe v2.1.0 · Barangay Bayanan BDRRMC</p>
      </div>
    </div>
  );
}

// ─── Bottom Navigation ────────────────────────────────────────────────────────
function BottomNav({ active, onChange }: { active: Screen; onChange: (s: Screen) => void }) {
  const tabs: { key: Screen; label: string; icon: typeof Home }[] = [
    { key: "home", label: "Home", icon: Home },
    { key: "report", label: "Report", icon: FileText },
    { key: "map", label: "Map", icon: Map },
    { key: "alerts", label: "Alerts", icon: Bell },
    { key: "profile", label: "Profile", icon: User },
  ];

  return (
    <div
      className="flex items-center justify-around py-2 bg-white"
      style={{ borderTop: "1px solid #E0E0E0", paddingBottom: "env(safe-area-inset-bottom, 8px)" }}
    >
      {tabs.map(({ key, label, icon: Icon }) => {
        const isActive = active === key;
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className="flex flex-col items-center gap-1 px-3 py-1 relative"
          >
            {isActive && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 rounded-xl"
                style={{ backgroundColor: BLUE + "12" }}
              />
            )}
            <Icon size={22} color={isActive ? BLUE : "#9E9E9E"} strokeWidth={isActive ? 2.2 : 1.7} />
            <span className="text-[10px] font-medium" style={{ color: isActive ? BLUE : "#9E9E9E" }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [tabScreen, setTabScreen] = useState<Screen>("home");

  const mainTabs: Screen[] = ["home", "report", "map", "alerts", "profile"];
  const isTabScreen = mainTabs.includes(screen);

  const handleTabChange = (s: Screen) => {
    setTabScreen(s);
    setScreen(s);
  };

  const renderScreen = () => {
    switch (screen) {
      case "splash": return <SplashScreen onDone={() => setScreen("login")} />;
      case "login": return <LoginScreen onLogin={() => { setScreen("home"); setTabScreen("home"); }} />;
      case "home": return <HomeScreen onNavigate={s => setScreen(s)} />;
      case "report": return <ReportScreen onBack={() => { setScreen("home"); setTabScreen("home"); }} />;
      case "map": return <MapScreen />;
      case "alerts": return <AlertsScreen />;
      case "profile": return <ProfileScreen />;
      case "rescue": return <RescueScreen onBack={() => { setScreen("home"); setTabScreen("home"); }} />;
      case "family": return <FamilyScreen onBack={() => { setScreen("home"); setTabScreen("home"); }} />;
      default: return null;
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen" style={{ backgroundColor: "#1565C0" }}>
      {/* Mobile frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          maxHeight: "100vh",
          borderRadius: 40,
          boxShadow: "0 40px 80px rgba(0,0,0,0.4), 0 0 0 8px #0D47A1",
          backgroundColor: "#F7F9FC",
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-7 py-2 bg-white flex-shrink-0" style={{ fontSize: 11, color: "#212121" }}>
          <span className="font-semibold">9:41</span>
          <div className="flex items-center gap-1">
            <div className="flex gap-0.5 items-end">
              {[3, 5, 7, 9].map((h, i) => (
                <div key={i} className="w-1 rounded-sm" style={{ height: h, backgroundColor: i < 3 ? "#212121" : "#BDBDBD" }} />
              ))}
            </div>
            <svg width="15" height="11" viewBox="0 0 15 11" fill="none">
              <path d="M7.5 2.5 C10 2.5 12.2 3.7 13.7 5.5 C12.2 7.3 10 8.5 7.5 8.5 C5 8.5 2.8 7.3 1.3 5.5 C2.8 3.7 5 2.5 7.5 2.5Z" stroke="#212121" strokeWidth="1.2" fill="none" />
              <circle cx="7.5" cy="5.5" r="1.8" fill="#212121" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="rounded-sm" style={{ width: 22, height: 11, border: "1px solid #212121", padding: 2, position: "relative" }}>
                <div className="rounded-sm" style={{ width: "70%", height: "100%", backgroundColor: "#212121" }} />
              </div>
            </div>
          </div>
        </div>

        {/* Screen content */}
        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={screen}
              initial={{ opacity: 0, x: screen === "splash" || screen === "login" ? 0 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              className="absolute inset-0"
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom navigation */}
        {isTabScreen && (
          <BottomNav active={tabScreen} onChange={handleTabChange} />
        )}
      </div>
    </div>
  );
}
